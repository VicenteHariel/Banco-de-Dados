--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.14
-- Dumped by pg_dump version 9.5.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.usuario DROP CONSTRAINT usuario_id_pessoa_fkey1;
ALTER TABLE ONLY public.usuario DROP CONSTRAINT usuario_id_pessoa_fkey;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_id_pessoa_fkey1;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_id_pessoa_fkey;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_id_categoria_fkey1;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_id_categoria_fkey;
ALTER TABLE ONLY public.produto_estoque DROP CONSTRAINT produto_estoque_id_produto_fkey1;
ALTER TABLE ONLY public.produto_estoque DROP CONSTRAINT produto_estoque_id_produto_fkey;
ALTER TABLE ONLY public.pessoa DROP CONSTRAINT pessoa_id_pessoa_tipo_fkey;
ALTER TABLE ONLY public.pedido DROP CONSTRAINT pedido_id_usuario_fkey;
ALTER TABLE ONLY public.pedido DROP CONSTRAINT pedido_id_frete_fkey1;
ALTER TABLE ONLY public.pedido DROP CONSTRAINT pedido_id_frete_fkey;
ALTER TABLE ONLY public.item_pedido DROP CONSTRAINT item_pedido_id_pedido_fkey;
ALTER TABLE ONLY public.item_pedido DROP CONSTRAINT item_pedido_id_estoque_fkey;
ALTER TABLE ONLY public.imagens DROP CONSTRAINT imagens_id_produto_fkey;
ALTER TABLE ONLY public.frete DROP CONSTRAINT frete_id_transporte_fkey1;
ALTER TABLE ONLY public.frete DROP CONSTRAINT frete_id_transporte_fkey;
ALTER TABLE ONLY public.endereco DROP CONSTRAINT endereco_id_pessoa_fkey;
ALTER TABLE ONLY public.usuario DROP CONSTRAINT usuario_pkey;
ALTER TABLE ONLY public.transporte DROP CONSTRAINT transporte_pkey;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_pkey;
ALTER TABLE ONLY public.produto_estoque DROP CONSTRAINT produto_estoque_pkey;
ALTER TABLE ONLY public.pessoa_tipo DROP CONSTRAINT pessoa_tipo_pkey;
ALTER TABLE ONLY public.pessoa DROP CONSTRAINT pessoa_pkey;
ALTER TABLE ONLY public.pedido DROP CONSTRAINT pedido_pkey;
ALTER TABLE ONLY public.item_pedido DROP CONSTRAINT item_pedido_pkey;
ALTER TABLE ONLY public.imagens DROP CONSTRAINT imagens_pkey;
ALTER TABLE ONLY public.frete DROP CONSTRAINT frete_pkey;
ALTER TABLE ONLY public.endereco DROP CONSTRAINT endereco_pkey;
ALTER TABLE ONLY public.categoria DROP CONSTRAINT categoria_pkey;
DROP TABLE public.usuario;
DROP TABLE public.transporte;
DROP TABLE public.produto_estoque;
DROP TABLE public.produto;
DROP TABLE public.pessoa_tipo;
DROP TABLE public.pessoa;
DROP TABLE public.pedido;
DROP TABLE public.item_pedido;
DROP TABLE public.imagens;
DROP TABLE public.frete;
DROP TABLE public.endereco;
DROP TABLE public.categoria;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    id_categoria integer NOT NULL,
    cat_descricao character varying(255)
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endereco (
    id_pessoa integer NOT NULL,
    cep character varying(8),
    pais character varying(100),
    numero integer,
    cidade character varying(100),
    rua character varying(150)
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: frete; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.frete (
    id_frete integer NOT NULL,
    faixa_de character varying(8),
    faixa_ate character varying(8),
    valor_frete double precision,
    id_transporte integer
);


ALTER TABLE public.frete OWNER TO postgres;

--
-- Name: imagens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.imagens (
    id_imagem integer NOT NULL,
    img_descricao character varying(255),
    id_produto integer
);


ALTER TABLE public.imagens OWNER TO postgres;

--
-- Name: item_pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_pedido (
    id_estoque integer NOT NULL,
    id_pedido integer NOT NULL
);


ALTER TABLE public.item_pedido OWNER TO postgres;

--
-- Name: pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido (
    id_pedido integer NOT NULL,
    data_pagamento date,
    data_pedido date,
    id_usuario integer,
    id_frete integer
);


ALTER TABLE public.pedido OWNER TO postgres;

--
-- Name: pessoa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pessoa (
    id_pessoa integer NOT NULL,
    nome character varying(100),
    data_nasc date,
    cpf_cnpj character varying(14),
    filial boolean,
    id_pessoa_tipo integer
);


ALTER TABLE public.pessoa OWNER TO postgres;

--
-- Name: pessoa_tipo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pessoa_tipo (
    id_pessoa_tipo integer NOT NULL,
    nome_tipo character varying(100)
);


ALTER TABLE public.pessoa_tipo OWNER TO postgres;

--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto (
    id_produto integer NOT NULL,
    descricao character varying(255),
    valor double precision,
    id_pessoa integer,
    id_categoria integer
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: produto_estoque; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto_estoque (
    id_estoque integer NOT NULL,
    id_produto integer
);


ALTER TABLE public.produto_estoque OWNER TO postgres;

--
-- Name: transporte; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transporte (
    id_transporte integer NOT NULL,
    nome_transporte character varying(100),
    ativo boolean
);


ALTER TABLE public.transporte OWNER TO postgres;

--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    id_usuario integer NOT NULL,
    login character varying(20),
    senha character varying(30),
    ativo boolean,
    id_pessoa integer
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categoria (id_categoria, cat_descricao) FROM stdin;
\.
COPY public.categoria (id_categoria, cat_descricao) FROM '$$PATH$$/2184.dat';

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.endereco (id_pessoa, cep, pais, numero, cidade, rua) FROM stdin;
\.
COPY public.endereco (id_pessoa, cep, pais, numero, cidade, rua) FROM '$$PATH$$/2186.dat';

--
-- Data for Name: frete; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.frete (id_frete, faixa_de, faixa_ate, valor_frete, id_transporte) FROM stdin;
\.
COPY public.frete (id_frete, faixa_de, faixa_ate, valor_frete, id_transporte) FROM '$$PATH$$/2189.dat';

--
-- Data for Name: imagens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.imagens (id_imagem, img_descricao, id_produto) FROM stdin;
\.
COPY public.imagens (id_imagem, img_descricao, id_produto) FROM '$$PATH$$/2185.dat';

--
-- Data for Name: item_pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_pedido (id_estoque, id_pedido) FROM stdin;
\.
COPY public.item_pedido (id_estoque, id_pedido) FROM '$$PATH$$/2188.dat';

--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedido (id_pedido, data_pagamento, data_pedido, id_usuario, id_frete) FROM stdin;
\.
COPY public.pedido (id_pedido, data_pagamento, data_pedido, id_usuario, id_frete) FROM '$$PATH$$/2182.dat';

--
-- Data for Name: pessoa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pessoa (id_pessoa, nome, data_nasc, cpf_cnpj, filial, id_pessoa_tipo) FROM stdin;
\.
COPY public.pessoa (id_pessoa, nome, data_nasc, cpf_cnpj, filial, id_pessoa_tipo) FROM '$$PATH$$/2187.dat';

--
-- Data for Name: pessoa_tipo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pessoa_tipo (id_pessoa_tipo, nome_tipo) FROM stdin;
\.
COPY public.pessoa_tipo (id_pessoa_tipo, nome_tipo) FROM '$$PATH$$/2180.dat';

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produto (id_produto, descricao, valor, id_pessoa, id_categoria) FROM stdin;
\.
COPY public.produto (id_produto, descricao, valor, id_pessoa, id_categoria) FROM '$$PATH$$/2183.dat';

--
-- Data for Name: produto_estoque; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produto_estoque (id_estoque, id_produto) FROM stdin;
\.
COPY public.produto_estoque (id_estoque, id_produto) FROM '$$PATH$$/2179.dat';

--
-- Data for Name: transporte; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transporte (id_transporte, nome_transporte, ativo) FROM stdin;
\.
COPY public.transporte (id_transporte, nome_transporte, ativo) FROM '$$PATH$$/2190.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario (id_usuario, login, senha, ativo, id_pessoa) FROM stdin;
\.
COPY public.usuario (id_usuario, login, senha, ativo, id_pessoa) FROM '$$PATH$$/2181.dat';

--
-- Name: categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (id_categoria);


--
-- Name: endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (id_pessoa);


--
-- Name: frete_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.frete
    ADD CONSTRAINT frete_pkey PRIMARY KEY (id_frete);


--
-- Name: imagens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imagens
    ADD CONSTRAINT imagens_pkey PRIMARY KEY (id_imagem);


--
-- Name: item_pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_pedido
    ADD CONSTRAINT item_pedido_pkey PRIMARY KEY (id_estoque, id_pedido);


--
-- Name: pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (id_pedido);


--
-- Name: pessoa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa
    ADD CONSTRAINT pessoa_pkey PRIMARY KEY (id_pessoa);


--
-- Name: pessoa_tipo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa_tipo
    ADD CONSTRAINT pessoa_tipo_pkey PRIMARY KEY (id_pessoa_tipo);


--
-- Name: produto_estoque_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_estoque
    ADD CONSTRAINT produto_estoque_pkey PRIMARY KEY (id_estoque);


--
-- Name: produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (id_produto);


--
-- Name: transporte_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transporte
    ADD CONSTRAINT transporte_pkey PRIMARY KEY (id_transporte);


--
-- Name: usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id_usuario);


--
-- Name: endereco_id_pessoa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_id_pessoa_fkey FOREIGN KEY (id_pessoa) REFERENCES public.pessoa(id_pessoa);


--
-- Name: frete_id_transporte_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.frete
    ADD CONSTRAINT frete_id_transporte_fkey FOREIGN KEY (id_transporte) REFERENCES public.transporte(id_transporte);


--
-- Name: frete_id_transporte_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.frete
    ADD CONSTRAINT frete_id_transporte_fkey1 FOREIGN KEY (id_transporte) REFERENCES public.transporte(id_transporte);


--
-- Name: imagens_id_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.imagens
    ADD CONSTRAINT imagens_id_produto_fkey FOREIGN KEY (id_produto) REFERENCES public.produto(id_produto);


--
-- Name: item_pedido_id_estoque_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_pedido
    ADD CONSTRAINT item_pedido_id_estoque_fkey FOREIGN KEY (id_estoque) REFERENCES public.produto_estoque(id_estoque);


--
-- Name: item_pedido_id_pedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_pedido
    ADD CONSTRAINT item_pedido_id_pedido_fkey FOREIGN KEY (id_pedido) REFERENCES public.pedido(id_pedido);


--
-- Name: pedido_id_frete_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_id_frete_fkey FOREIGN KEY (id_frete) REFERENCES public.frete(id_frete);


--
-- Name: pedido_id_frete_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_id_frete_fkey1 FOREIGN KEY (id_frete) REFERENCES public.frete(id_frete);


--
-- Name: pedido_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuario(id_usuario);


--
-- Name: pessoa_id_pessoa_tipo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa
    ADD CONSTRAINT pessoa_id_pessoa_tipo_fkey FOREIGN KEY (id_pessoa_tipo) REFERENCES public.pessoa_tipo(id_pessoa_tipo);


--
-- Name: produto_estoque_id_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_estoque
    ADD CONSTRAINT produto_estoque_id_produto_fkey FOREIGN KEY (id_produto) REFERENCES public.produto(id_produto);


--
-- Name: produto_estoque_id_produto_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto_estoque
    ADD CONSTRAINT produto_estoque_id_produto_fkey1 FOREIGN KEY (id_produto) REFERENCES public.produto(id_produto);


--
-- Name: produto_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categoria(id_categoria);


--
-- Name: produto_id_categoria_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_id_categoria_fkey1 FOREIGN KEY (id_categoria) REFERENCES public.categoria(id_categoria);


--
-- Name: produto_id_pessoa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_id_pessoa_fkey FOREIGN KEY (id_pessoa) REFERENCES public.pessoa(id_pessoa);


--
-- Name: produto_id_pessoa_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_id_pessoa_fkey1 FOREIGN KEY (id_pessoa) REFERENCES public.pessoa(id_pessoa);


--
-- Name: usuario_id_pessoa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_id_pessoa_fkey FOREIGN KEY (id_pessoa) REFERENCES public.pessoa(id_pessoa);


--
-- Name: usuario_id_pessoa_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_id_pessoa_fkey1 FOREIGN KEY (id_pessoa) REFERENCES public.pessoa(id_pessoa);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

